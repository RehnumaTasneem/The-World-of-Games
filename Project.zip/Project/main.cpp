#include <GL/glut.h>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <iostream>
#include <set>
#include <cmath>
#include <cstring>
#include <fstream>

using namespace std;

// ==============================================
// GLOBAL CONSTANTS & VARIABLES
// ==============================================
const int WINDOW_WIDTH = 1000;
const int WINDOW_HEIGHT = 700;

// Game Selection State
enum GameSelection { MAIN_MENU, CANDY_CRUSH, TIC_TAC_TOE, TETRIS };
GameSelection currentScreen = MAIN_MENU;

// Font Constants
#define FONT_LARGE GLUT_BITMAP_TIMES_ROMAN_24
#define FONT_MEDIUM GLUT_BITMAP_HELVETICA_18
#define FONT_SMALL GLUT_BITMAP_HELVETICA_12

// Menu Buttons
struct Button {
    float x, y, width, height;
    string text;
    bool hover;
    int id;
};

vector<Button> menuButtons;
Button backButton;

// Animation variables
float titleY = -100;
float bgOffset = 0;
float sparkleTime = 0;

// ==============================================
// TETRIS GAME VARIABLES - FIXED
// ==============================================
const int TETRIS_ROWS = 20;
const int TETRIS_COLS = 10;
const int TETRIS_BLOCK_SIZE = 30;
const int TETRIS_UI_WIDTH = 200;
const int TETRIS_BOARD_WIDTH = TETRIS_COLS * TETRIS_BLOCK_SIZE;
const int TETRIS_BOARD_HEIGHT = TETRIS_ROWS * TETRIS_BLOCK_SIZE;
const int TETRIS_OFFSET_X = 50;
const int TETRIS_OFFSET_Y = 100;

int tetrisBoard[TETRIS_ROWS][TETRIS_COLS] = {0};
int tetrisScore = 0, tetrisHighScore = 0, tetrisLevel = 1, tetrisLinesCleared = 0;
float tetrisInitialDelay = 0.5f, tetrisDelay = tetrisInitialDelay;

enum TetrisGameState { TETRIS_MENU, TETRIS_PLAYING, TETRIS_PAUSED, TETRIS_GAMEOVER };
TetrisGameState tetrisGameState = TETRIS_PLAYING;

struct TetrisPoint { int x, y; } tetrisCurrent[4], tetrisTemp[4];
int tetrisCurrentType, tetrisNextType;
int tetrisCurrentColor, tetrisNextColor;
bool tetrisRotateFlag = false;
int tetrisDx = 0;

int tetrisFigures[7][4] = {
    {1, 3, 5, 7}, {2, 4, 5, 7}, {3, 5, 4, 6},
    {3, 5, 4, 7}, {2, 3, 5, 7}, {3, 5, 7, 6}, {2, 3, 4, 5}
};

float tetrisColors[8][3] = {
    {0, 0, 0},          // Black (empty)
    {0, 1, 1},          // Cyan (I)
    {1, 0, 0},          // Red (Z)
    {0, 1, 0},          // Green (S)
    {0, 0, 1},          // Blue (J)
    {1, 1, 0},          // Yellow (O)
    {1, 0, 1},          // Purple (T)
    {1, 0.5, 0}         // Orange (L)
};

bool tetrisShowLevelUp = false;
float tetrisLevelUpTime = 0.0f;

// ==============================================
// CANDY CRUSH VARIABLES
// ==============================================
const int GRID_SIZE = 8;
const int CANDY_TYPES = 6;
const int CELL_SIZE = 60;

float candyColors[CANDY_TYPES][3] = {
    {1.0f, 0.0f, 0.0f}, {0.0f, 1.0f, 0.0f}, {0.0f, 0.0f, 1.0f},
    {1.0f, 1.0f, 0.0f}, {1.0f, 0.0f, 1.0f}, {1.0f, 0.5f, 0.0f}
};

int candyGrid[GRID_SIZE][GRID_SIZE];
int selectedX = -1, selectedY = -1;
int candyScore = 0;
int candyMoves = 20;
bool isAnimating = false;
bool isSwapping = false;
int animationStep = 0;
const int ANIMATION_STEPS = 15;
int swapX1, swapY1, swapX2, swapY2;
int swapCandy1, swapCandy2;

// ==============================================
// TIC TAC TOE VARIABLES
// ==============================================
int tttGrid[3][3];
int tttTurn = 1;
int player1Score = 0;
int player2Score = 0;
bool tttGameOver = false;
int tttResult = -1;
int tttHighlight = 0;

// ==============================================
// UTILITY FUNCTIONS
// ==============================================
int getTextWidth(string text, void* font) {
    int width = 0;
    for (char c : text) width += glutBitmapWidth(font, c);
    return width;
}

void drawText(float x, float y, string text, void* font) {
    glRasterPos2f(x, y);
    for (char c : text) glutBitmapCharacter(font, c);
}

void drawRoundedRect(float x, float y, float w, float h, float radius) {
    const int segments = 20;
    glBegin(GL_POLYGON);

    // Top edge
    for (int i = 0; i <= segments; i++) {
        float angle = 3.14159f * 0.5f * i / segments;
        glVertex2f(x + w - radius + cos(angle) * radius,
                   y + h - radius + sin(angle) * radius);
    }

    // Right edge
    for (int i = 0; i <= segments; i++) {
        float angle = 3.14159f * 0.5f + 3.14159f * 0.5f * i / segments;
        glVertex2f(x + w - radius + cos(angle) * radius,
                   y + radius + sin(angle) * radius);
    }

    // Bottom edge
    for (int i = 0; i <= segments; i++) {
        float angle = 3.14159f + 3.14159f * 0.5f * i / segments;
        glVertex2f(x + radius + cos(angle) * radius,
                   y + radius + sin(angle) * radius);
    }

    // Left edge
    for (int i = 0; i <= segments; i++) {
        float angle = 3.14159f * 1.5f + 3.14159f * 0.5f * i / segments;
        glVertex2f(x + radius + cos(angle) * radius,
                   y + h - radius + sin(angle) * radius);
    }
    glEnd();
}

void drawGradientBackground() {
    bgOffset += 0.002f;
    float t = sin(bgOffset) * 0.1f;

    glBegin(GL_QUADS);
    glColor3f(0.15f + t, 0.1f, 0.25f + t);
    glVertex2f(0, 0);
    glVertex2f(WINDOW_WIDTH, 0);
    glColor3f(0.08f, 0.12f + t, 0.2f);
    glVertex2f(WINDOW_WIDTH, WINDOW_HEIGHT);
    glVertex2f(0, WINDOW_HEIGHT);
    glEnd();
}

void drawSparkles() {
    sparkleTime += 0.05f;

    for (int i = 0; i < 15; i++) {
        float x = fmod(sparkleTime * 20 + i * 67, WINDOW_WIDTH);
        float y = 100 + 50 * sin(sparkleTime + i);
        float size = 2 + 1.5f * sin(sparkleTime * 2 + i);
        float alpha = 0.5f + 0.5f * sin(sparkleTime * 3 + i);

        glColor4f(1, 1, 1, alpha);
        glBegin(GL_QUADS);
        glVertex2f(x - size, y - size);
        glVertex2f(x + size, y - size);
        glVertex2f(x + size, y + size);
        glVertex2f(x - size, y + size);
        glEnd();
    }
}

void drawButton(Button btn) {
    // Button shadow
    glColor3f(0.1f, 0.1f, 0.1f);
    drawRoundedRect(btn.x + 3, btn.y - 3, btn.width, btn.height, 15);

    // Button body
    if (btn.hover) {
        glColor3f(0.3f, 0.6f, 1.0f);
    } else {
        glColor3f(0.2f, 0.4f, 0.8f);
    }
    drawRoundedRect(btn.x, btn.y, btn.width, btn.height, 15);

    // Button text - perfectly centered
    glColor3f(1.0f, 1.0f, 1.0f);
    float textX = btn.x + (btn.width - getTextWidth(btn.text, FONT_MEDIUM)) / 2;
    float textY = btn.y + (btn.height - 18) / 2 + 7;
    drawText(textX, textY, btn.text, FONT_MEDIUM);
}

void initMenu() {
    menuButtons.clear();

    // Game selection buttons
    float buttonWidth = 300;
    float buttonHeight = 60;
    float startX = (WINDOW_WIDTH - buttonWidth) / 2;
    float startY = 300;
    float spacing = 80;

    menuButtons.push_back({startX, startY, buttonWidth, buttonHeight,
                          "🍬 CANDY CRUSH DELUXE", false, 1});

    menuButtons.push_back({startX, startY + spacing, buttonWidth, buttonHeight,
                          "⭕ TIC TAC TOE", false, 2});

    menuButtons.push_back({startX, startY - spacing  , buttonWidth, buttonHeight,
                          "🎮 TETRIS", false, 3});

    menuButtons.push_back({startX, startY - spacing * 2, buttonWidth, buttonHeight,
                          "❌ EXIT", false, 4});

    // Back button (for games)
    backButton = {20, 20, 150, 40, "← MAIN MENU", false, 0};
}

// ==============================================
// TETRIS GAME FUNCTIONS - COMPLETELY FIXED
// ==============================================
void tetrisLoadHighScore() {
    ifstream file("tetris_highscore.txt");
    if (file.is_open()) {
        file >> tetrisHighScore;
        file.close();
    }
}

void tetrisSaveHighScore() {
    ofstream file("tetris_highscore.txt");
    if (file.is_open()) {
        file << tetrisHighScore;
        file.close();
    }
}

void tetrisUpdateLevel() {
    if (tetrisScore >= tetrisLevel * 100) {
        tetrisLevel++;
        tetrisDelay = tetrisInitialDelay * pow(0.9, tetrisLevel - 1);

        tetrisShowLevelUp = true;
        tetrisLevelUpTime = glutGet(GLUT_ELAPSED_TIME) / 1000.0f;
    }
}

void tetrisDrawBlock(int x, int y, int c) {
    float* color = tetrisColors[c];
    glColor3f(color[0], color[1], color[2]);
    glBegin(GL_QUADS);
    glVertex2f(x * TETRIS_BLOCK_SIZE, y * TETRIS_BLOCK_SIZE);
    glVertex2f((x + 1) * TETRIS_BLOCK_SIZE, y * TETRIS_BLOCK_SIZE);
    glVertex2f((x + 1) * TETRIS_BLOCK_SIZE, (y + 1) * TETRIS_BLOCK_SIZE);
    glVertex2f(x * TETRIS_BLOCK_SIZE, (y + 1) * TETRIS_BLOCK_SIZE);
    glEnd();

    glColor3f(0.1, 0.1, 0.1);
    glBegin(GL_LINE_LOOP);
    glVertex2f(x * TETRIS_BLOCK_SIZE, y * TETRIS_BLOCK_SIZE);
    glVertex2f((x + 1) * TETRIS_BLOCK_SIZE, y * TETRIS_BLOCK_SIZE);
    glVertex2f((x + 1) * TETRIS_BLOCK_SIZE, (y + 1) * TETRIS_BLOCK_SIZE);
    glVertex2f(x * TETRIS_BLOCK_SIZE, (y + 1) * TETRIS_BLOCK_SIZE);
    glEnd();
}

bool tetrisCheck() {
    for (int i = 0; i < 4; i++) {
        if (tetrisCurrent[i].x < 0 || tetrisCurrent[i].x >= TETRIS_COLS ||
            tetrisCurrent[i].y >= TETRIS_ROWS)
            return false;
        if (tetrisBoard[tetrisCurrent[i].y][tetrisCurrent[i].x])
            return false;
    }
    return true;
}

void tetrisSpawnPiece() {
    tetrisCurrentType = tetrisNextType;
    tetrisCurrentColor = tetrisNextColor;
    tetrisNextType = rand() % 7;
    tetrisNextColor = 1 + rand() % 7;

    for (int i = 0; i < 4; i++) {
        tetrisCurrent[i].x = tetrisFigures[tetrisCurrentType][i] % 2 + TETRIS_COLS / 2 - 1;
        tetrisCurrent[i].y = tetrisFigures[tetrisCurrentType][i] / 2;
    }

    if (!tetrisCheck()) {
        tetrisGameState = TETRIS_GAMEOVER;
        if (tetrisScore > tetrisHighScore) {
            tetrisHighScore = tetrisScore;
            tetrisSaveHighScore();
        }
    }
}

void tetrisRotate() {
    TetrisPoint p = tetrisCurrent[1];
    for (int i = 0; i < 4; i++) {
        int x = tetrisCurrent[i].y - p.y;
        int y = tetrisCurrent[i].x - p.x;
        tetrisCurrent[i].x = p.x - x;
        tetrisCurrent[i].y = p.y + y;
    }
    if (!tetrisCheck())
        for (int i = 0; i < 4; i++) tetrisCurrent[i] = tetrisTemp[i];
}

void tetrisTick() {
    // Store current position
    for (int i = 0; i < 4; i++) tetrisTemp[i] = tetrisCurrent[i];

    // Move horizontally
    for (int i = 0; i < 4; i++) tetrisCurrent[i].x += tetrisDx;
    if (!tetrisCheck())
        for (int i = 0; i < 4; i++) tetrisCurrent[i] = tetrisTemp[i];

    // Rotate if needed
    if (tetrisRotateFlag)
        tetrisRotate();

    // Store before moving down
    for (int i = 0; i < 4; i++) tetrisTemp[i] = tetrisCurrent[i];

    // Move down
    for (int i = 0; i < 4; i++) tetrisCurrent[i].y += 1;

    // Check collision after moving down
    if (!tetrisCheck()) {
        // Place piece on board
        for (int i = 0; i < 4; i++)
            tetrisBoard[tetrisTemp[i].y][tetrisTemp[i].x] = tetrisCurrentColor;
        tetrisScore += 10;
        tetrisUpdateLevel();
        tetrisSpawnPiece();
    }

    // Check for completed lines
    int k = TETRIS_ROWS - 1;
    int linesRemoved = 0;

    for (int i = TETRIS_ROWS - 1; i >= 0; i--) {
        int count = 0;
        for (int j = 0; j < TETRIS_COLS; j++)
            if (tetrisBoard[i][j]) count++;

        if (count < TETRIS_COLS) {
            // Keep this row
            for (int j = 0; j < TETRIS_COLS; j++)
                tetrisBoard[k][j] = tetrisBoard[i][j];
            k--;
        } else {
            // This line is complete
            linesRemoved++;
        }
    }

    // Fill empty rows at top
    while (k >= 0) {
        for (int j = 0; j < TETRIS_COLS; j++) tetrisBoard[k][j] = 0;
        k--;
    }

    // Update score for cleared lines
    if (linesRemoved > 0) {
        tetrisScore += 100 * linesRemoved;
        tetrisLinesCleared += linesRemoved;
        tetrisUpdateLevel();
    }

    // Reset movement flags
    tetrisDx = 0;
    tetrisRotateFlag = false;
}

void tetrisDrawText(float x, float y, const string& text, float r, float g, float b) {
    glColor3f(r, g, b);
    glRasterPos2f(x, y);
    for (char c : text)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, c);
}

void displayTetris() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Use main window dimensions for Tetris too
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, WINDOW_WIDTH, WINDOW_HEIGHT, 0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // Draw background
    drawGradientBackground();

    // Draw back button (using regular coordinates)
    backButton.x = 20;
    backButton.y = 20;
    drawButton(backButton);

    // Game title
    glColor3f(1.0f, 0.7f, 0.3f);
    string title = "🎮 TETRIS";
    float titleX = (WINDOW_WIDTH - getTextWidth(title, FONT_LARGE)) / 2;
    drawText(titleX, 80, title, FONT_LARGE);

    // Main container for Tetris game
    float containerX = (WINDOW_WIDTH - (TETRIS_BOARD_WIDTH + TETRIS_UI_WIDTH)) / 2;
    float containerY = 120;

    // Draw main container background
    glColor3f(0.15f, 0.15f, 0.25f);
    glBegin(GL_QUADS);
    glVertex2f(containerX - 10, containerY - 10);
    glVertex2f(containerX + TETRIS_BOARD_WIDTH + TETRIS_UI_WIDTH + 10, containerY - 10);
    glVertex2f(containerX + TETRIS_BOARD_WIDTH + TETRIS_UI_WIDTH + 10, containerY + TETRIS_BOARD_HEIGHT + 10);
    glVertex2f(containerX - 10, containerY + TETRIS_BOARD_HEIGHT + 10);
    glEnd();

    // Draw board background
    float boardX = containerX;
    float boardY = containerY;

    glColor3f(0.1f, 0.1f, 0.15f);
    glBegin(GL_QUADS);
    glVertex2f(boardX, boardY);
    glVertex2f(boardX + TETRIS_BOARD_WIDTH, boardY);
    glVertex2f(boardX + TETRIS_BOARD_WIDTH, boardY + TETRIS_BOARD_HEIGHT);
    glVertex2f(boardX, boardY + TETRIS_BOARD_HEIGHT);
    glEnd();

    // Draw grid lines
    glColor3f(0.3f, 0.3f, 0.4f);
    glLineWidth(1.0f);

    // Horizontal lines
    for (int i = 0; i <= TETRIS_ROWS; i++) {
        glBegin(GL_LINES);
        glVertex2f(boardX, boardY + i * TETRIS_BLOCK_SIZE);
        glVertex2f(boardX + TETRIS_BOARD_WIDTH, boardY + i * TETRIS_BLOCK_SIZE);
        glEnd();
    }

    // Vertical lines
    for (int i = 0; i <= TETRIS_COLS; i++) {
        glBegin(GL_LINES);
        glVertex2f(boardX + i * TETRIS_BLOCK_SIZE, boardY);
        glVertex2f(boardX + i * TETRIS_BLOCK_SIZE, boardY + TETRIS_BOARD_HEIGHT);
        glEnd();
    }

    // Draw board border
    glColor3f(0.5f, 0.5f, 0.8f);
    glLineWidth(3.0f);
    glBegin(GL_LINE_LOOP);
    glVertex2f(boardX, boardY);
    glVertex2f(boardX + TETRIS_BOARD_WIDTH, boardY);
    glVertex2f(boardX + TETRIS_BOARD_WIDTH, boardY + TETRIS_BOARD_HEIGHT);
    glVertex2f(boardX, boardY + TETRIS_BOARD_HEIGHT);
    glEnd();

    // Draw placed blocks
    for (int i = 0; i < TETRIS_ROWS; i++) {
        for (int j = 0; j < TETRIS_COLS; j++) {
            if (tetrisBoard[i][j]) {
                glPushMatrix();
                glTranslatef(boardX, boardY, 0);
                tetrisDrawBlock(j, i, tetrisBoard[i][j]);
                glPopMatrix();
            }
        }
    }

    // Draw current piece
    for (int i = 0; i < 4; i++) {
        glPushMatrix();
        glTranslatef(boardX, boardY, 0);
        tetrisDrawBlock(tetrisCurrent[i].x, tetrisCurrent[i].y, tetrisCurrentColor);
        glPopMatrix();
    }

    // Draw UI panel
    float panelX = boardX + TETRIS_BOARD_WIDTH + 10;
    float panelY = boardY;
    float panelWidth = TETRIS_UI_WIDTH - 20;
    float panelHeight = TETRIS_BOARD_HEIGHT;

    // Panel background
    glColor3f(0.1f, 0.1f, 0.15f);
    glBegin(GL_QUADS);
    glVertex2f(panelX, panelY);
    glVertex2f(panelX + panelWidth, panelY);
    glVertex2f(panelX + panelWidth, panelY + panelHeight);
    glVertex2f(panelX, panelY + panelHeight);
    glEnd();

    // Panel border
    glColor3f(0.5f, 0.5f, 0.8f);
    glLineWidth(2.0f);
    glBegin(GL_LINE_LOOP);
    glVertex2f(panelX, panelY);
    glVertex2f(panelX + panelWidth, panelY);
    glVertex2f(panelX + panelWidth, panelY + panelHeight);
    glVertex2f(panelX, panelY + panelHeight);
    glEnd();

    // Draw game info
    float textX = panelX + 15;
    float currentY = panelY + 40;

    // Score
    tetrisDrawText(textX, currentY, "SCORE:", 1.0f, 1.0f, 1.0f);
    tetrisDrawText(textX + 10, currentY + 30, to_string(tetrisScore), 1.0f, 1.0f, 0.5f);
    currentY += 70;

    // High Score
    tetrisDrawText(textX, currentY, "HIGH SCORE:", 1.0f, 1.0f, 1.0f);
    tetrisDrawText(textX + 10, currentY + 30, to_string(tetrisHighScore), 1.0f, 0.8f, 0.2f);
    currentY += 70;

    // Level
    tetrisDrawText(textX, currentY, "LEVEL:", 1.0f, 1.0f, 1.0f);
    tetrisDrawText(textX + 10, currentY + 30, to_string(tetrisLevel), 0.5f, 1.0f, 0.5f);
    currentY += 70;

    // Lines
    tetrisDrawText(textX, currentY, "LINES:", 1.0f, 1.0f, 1.0f);
    tetrisDrawText(textX + 10, currentY + 30, to_string(tetrisLinesCleared), 0.8f, 0.8f, 1.0f);
    currentY += 90;

    // Next Piece
    tetrisDrawText(textX, currentY, "NEXT PIECE:", 1.0f, 1.0f, 1.0f);
    currentY += 40;

    // Draw next piece preview
    float previewX = panelX + 50;
    float previewY = currentY;

    // Draw preview background
    glColor3f(0.2f, 0.2f, 0.3f);
    glBegin(GL_QUADS);
    glVertex2f(previewX - 10, previewY - 10);
    glVertex2f(previewX + 120, previewY - 10);
    glVertex2f(previewX + 120, previewY + 120);
    glVertex2f(previewX - 10, previewY + 120);
    glEnd();

    // Draw next piece blocks
    for (int i = 0; i < 4; i++) {
        int nx = tetrisFigures[tetrisNextType][i] % 2;
        int ny = tetrisFigures[tetrisNextType][i] / 2;

        glPushMatrix();
        glTranslatef(previewX + nx * TETRIS_BLOCK_SIZE, previewY + ny * TETRIS_BLOCK_SIZE, 0);
        tetrisDrawBlock(0, 0, tetrisNextColor);
        glPopMatrix();
    }


    // Level Up message
    if (tetrisShowLevelUp) {
        float currentTime = glutGet(GLUT_ELAPSED_TIME) / 1000.0f;
        if (currentTime - tetrisLevelUpTime < 2.0f) {
            float centerX = WINDOW_WIDTH / 2 - 60;
            float centerY = WINDOW_HEIGHT / 2;

            // Semi-transparent overlay
            glColor4f(0.0f, 0.0f, 0.0f, 0.5f);
            glBegin(GL_QUADS);
            glVertex2f(0, 0);
            glVertex2f(WINDOW_WIDTH, 0);
            glVertex2f(WINDOW_WIDTH, WINDOW_HEIGHT);
            glVertex2f(0, WINDOW_HEIGHT);
            glEnd();

            tetrisDrawText(centerX, centerY, "LEVEL UP!", 1.0f, 1.0f, 0.0f);
        } else {
            tetrisShowLevelUp = false;
        }
    }

    // Game state messages
    if (tetrisGameState == TETRIS_GAMEOVER) {
        float centerX = WINDOW_WIDTH / 2 - 100;
        float centerY = WINDOW_HEIGHT / 2;

        // Semi-transparent overlay
        glColor4f(0.0f, 0.0f, 0.0f, 0.7f);
        glBegin(GL_QUADS);
        glVertex2f(0, 0);
        glVertex2f(WINDOW_WIDTH, 0);
        glVertex2f(WINDOW_WIDTH, WINDOW_HEIGHT);
        glVertex2f(0, WINDOW_HEIGHT);
        glEnd();

        tetrisDrawText(centerX, centerY, "GAME OVER!", 1, 0, 0);
        tetrisDrawText(centerX - 20, centerY + 40, "Press R to Restart", 1, 1, 1);
        tetrisDrawText(centerX - 10, centerY + 80, "ESC for Main Menu", 1, 1, 1);
    } else if (tetrisGameState == TETRIS_PAUSED) {
        float centerX = WINDOW_WIDTH / 2 - 50;
        float centerY = WINDOW_HEIGHT / 2;

        // Semi-transparent overlay
        glColor4f(0.0f, 0.0f, 0.0f, 0.7f);
        glBegin(GL_QUADS);
        glVertex2f(0, 0);
        glVertex2f(WINDOW_WIDTH, 0);
        glVertex2f(WINDOW_WIDTH, WINDOW_HEIGHT);
        glVertex2f(0, WINDOW_HEIGHT);
        glEnd();

        tetrisDrawText(centerX, centerY, "PAUSED", 1, 1, 0);
        tetrisDrawText(centerX - 40, centerY + 40, "Press P to Continue", 1, 1, 1);
        tetrisDrawText(centerX - 30, centerY + 80, "ESC for Main Menu", 1, 1, 1);
    }

    glutSwapBuffers();
}

void tetrisResetGame() {
    tetrisScore = 0;
    tetrisLevel = 1;
    tetrisLinesCleared = 0;
    tetrisDelay = tetrisInitialDelay;

    // Clear board
    for (int i = 0; i < TETRIS_ROWS; i++)
        for (int j = 0; j < TETRIS_COLS; j++)
            tetrisBoard[i][j] = 0;

    // Initialize next piece
    tetrisNextType = rand() % 7;
    tetrisNextColor = 1 + rand() % 7;

    // Spawn first piece
    tetrisSpawnPiece();
    tetrisGameState = TETRIS_PLAYING;
}

void tetrisTimer(int value) {
    if (tetrisGameState == TETRIS_PLAYING) {
        tetrisTick();
        glutPostRedisplay();
    }
    glutTimerFunc((int)(tetrisDelay * 1000), tetrisTimer, 0);
}

void initTetris() {
    srand(time(0));
    tetrisLoadHighScore();
    tetrisResetGame();
}

// ==============================================
// CANDY CRUSH FUNCTIONS
// ==============================================
bool candyHasMatches() {
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            if (j <= GRID_SIZE - 3) {
                if (candyGrid[i][j] >= 0 && candyGrid[i][j] == candyGrid[i][j+1] && candyGrid[i][j] == candyGrid[i][j+2]) {
                    return true;
                }
            }
            if (i <= GRID_SIZE - 3) {
                if (candyGrid[i][j] >= 0 && candyGrid[i][j] == candyGrid[i+1][j] && candyGrid[i][j] == candyGrid[i+2][j]) {
                    return true;
                }
            }
        }
    }
    return false;
}

set<pair<int, int>> candyFindMatches() {
    set<pair<int, int>> matches;

    // Horizontal matches
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE - 2; j++) {
            if (candyGrid[i][j] >= 0 && candyGrid[i][j] == candyGrid[i][j+1] && candyGrid[i][j] == candyGrid[i][j+2]) {
                matches.insert({i, j});
                matches.insert({i, j+1});
                matches.insert({i, j+2});

                int k = j + 3;
                while (k < GRID_SIZE && candyGrid[i][j] == candyGrid[i][k]) {
                    matches.insert({i, k});
                    k++;
                }
            }
        }
    }

    // Vertical matches
    for (int i = 0; i < GRID_SIZE - 2; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            if (candyGrid[i][j] >= 0 && candyGrid[i][j] == candyGrid[i+1][j] && candyGrid[i][j] == candyGrid[i+2][j]) {
                matches.insert({i, j});
                matches.insert({i+1, j});
                matches.insert({i+2, j});

                int k = i + 3;
                while (k < GRID_SIZE && candyGrid[i][j] == candyGrid[k][j]) {
                    matches.insert({k, j});
                    k++;
                }
            }
        }
    }

    return matches;
}

void candyProcessMatches() {
    set<pair<int, int>> matches = candyFindMatches();

    if (matches.empty()) {
        // If no matches after swap, swap back
        if (isSwapping) {
            swap(candyGrid[swapX1][swapY1], candyGrid[swapX2][swapY2]);
            isSwapping = false;
            candyMoves++; // Don't count invalid move
        }
        isAnimating = false;
        return;
    }

    // Remove matched candies
    for (auto& match : matches) {
        candyGrid[match.first][match.second] = -1;
        candyScore += 10;
    }

    // Let candies fall
    for (int col = 0; col < GRID_SIZE; col++) {
        int emptyRow = GRID_SIZE - 1;

        for (int row = GRID_SIZE - 1; row >= 0; row--) {
            if (candyGrid[row][col] != -1) {
                candyGrid[emptyRow][col] = candyGrid[row][col];
                if (emptyRow != row) candyGrid[row][col] = -1;
                emptyRow--;
            }
        }

        // Fill empty spaces with new candies
        for (int row = emptyRow; row >= 0; row--) {
            candyGrid[row][col] = rand() % CANDY_TYPES;
        }
    }

    // Check for more matches
    if (candyHasMatches()) {
        isAnimating = true;
        animationStep = 0;
    } else {
        isAnimating = false;
        isSwapping = false;
        candyMoves--;
        if (candyMoves <= 0) {
            // Game over
        }
    }
}

void initCandyGrid() {
    srand(time(0));

    do {
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                candyGrid[i][j] = rand() % CANDY_TYPES;
            }
        }

        // Ensure no initial matches
        for (int attempts = 0; attempts < 100 && candyHasMatches(); attempts++) {
            for (int i = 0; i < GRID_SIZE; i++) {
                for (int j = 0; j < GRID_SIZE; j++) {
                    if (j > 0 && j < GRID_SIZE-1) {
                        if (candyGrid[i][j-1] == candyGrid[i][j] && candyGrid[i][j] == candyGrid[i][j+1]) {
                            candyGrid[i][j] = (candyGrid[i][j] + 1) % CANDY_TYPES;
                        }
                    }
                    if (i > 0 && i < GRID_SIZE-1) {
                        if (candyGrid[i-1][j] == candyGrid[i][j] && candyGrid[i][j] == candyGrid[i+1][j]) {
                            candyGrid[i][j] = (candyGrid[i][j] + 1) % CANDY_TYPES;
                        }
                    }
                }
            }
        }
    } while (candyHasMatches());

    selectedX = -1;
    selectedY = -1;
    candyScore = 0;
    candyMoves = 20;
    isAnimating = false;
    isSwapping = false;
}

void drawCandy(int x, int y, int type, bool selected = false) {
    if (type < 0) return;

    float posX = 200 + x * CELL_SIZE;
    float posY = 100 + y * CELL_SIZE;

    // Candy body
    glColor3fv(candyColors[type]);
    glBegin(GL_QUADS);
    glVertex2f(posX + 2, posY + 2);
    glVertex2f(posX + CELL_SIZE - 8, posY + 2);
    glVertex2f(posX + CELL_SIZE - 8, posY + CELL_SIZE - 8);
    glVertex2f(posX + 2, posY + CELL_SIZE - 8);
    glEnd();

    // Candy highlight
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(posX + 5, posY + CELL_SIZE - 10);
    glVertex2f(posX + CELL_SIZE - 10, posY + CELL_SIZE - 10);
    glVertex2f(posX + CELL_SIZE - 10, posY + 5);
    glVertex2f(posX + 5, posY + 5);
    glEnd();

    if (selected) {
        glColor3f(1.0f, 1.0f, 1.0f);
        glLineWidth(3.0f);
        glBegin(GL_LINE_LOOP);
        glVertex2f(posX, posY);
        glVertex2f(posX + CELL_SIZE - 6, posY);
        glVertex2f(posX + CELL_SIZE - 6, posY + CELL_SIZE - 6);
        glVertex2f(posX, posY + CELL_SIZE - 6);
        glEnd();
    }
}

void displayCandyCrush() {
    glClear(GL_COLOR_BUFFER_BIT);
    drawGradientBackground();

    // Draw back button
    drawButton(backButton);

    // Game title
    glColor3f(1.0f, 0.5f, 0.5f);
    string title = "🍬 CANDY CRUSH DELUXE";
    float titleX = (WINDOW_WIDTH - getTextWidth(title, FONT_LARGE)) / 2;
    drawText(titleX, 650, title, FONT_LARGE);

    // Game board background
    float boardX = 200;
    float boardY = 100;
    float boardSize = GRID_SIZE * CELL_SIZE;

    glColor3f(0.2f, 0.2f, 0.3f);
    glBegin(GL_QUADS);
    glVertex2f(boardX - 5, boardY - 5);
    glVertex2f(boardX + boardSize + 5, boardY - 5);
    glVertex2f(boardX + boardSize + 5, boardY + boardSize + 5);
    glVertex2f(boardX - 5, boardY + boardSize + 5);
    glEnd();

    // Grid lines
    glColor3f(0.3f, 0.3f, 0.4f);
    glLineWidth(2.0f);
    for (int i = 0; i <= GRID_SIZE; i++) {
        glBegin(GL_LINES);
        glVertex2f(boardX + i * CELL_SIZE, boardY);
        glVertex2f(boardX + i * CELL_SIZE, boardY + boardSize);
        glEnd();
    }
    for (int i = 0; i <= GRID_SIZE; i++) {
        glBegin(GL_LINES);
        glVertex2f(boardX, boardY + i * CELL_SIZE);
        glVertex2f(boardX + boardSize, boardY + i * CELL_SIZE);
        glEnd();
    }

    // Draw candies
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            bool selected = (i == selectedX && j == selectedY);
            drawCandy(j, i, candyGrid[i][j], selected);
        }
    }

    // Side panel
    float panelX = boardX + boardSize + 20;
    float panelWidth = WINDOW_WIDTH - panelX - 20;

    glColor3f(0.2f, 0.2f, 0.3f);
    drawRoundedRect(panelX, boardY, panelWidth, 400, 15);

    // Score and moves
    float infoStartX = panelX + 30;
    float currentY = boardY + 50;

    glColor3f(1.0f, 1.0f, 1.0f);
    drawText(infoStartX, currentY, "SCORE:", FONT_MEDIUM);
    currentY += 40;

    glColor3f(1.0f, 1.0f, 0.5f);
    char scoreStr[50];
    sprintf(scoreStr, "%d", candyScore);
    drawText(infoStartX, currentY, scoreStr, FONT_MEDIUM);
    currentY += 80;

    glColor3f(1.0f, 1.0f, 1.0f);
    drawText(infoStartX, currentY, "MOVES LEFT:", FONT_MEDIUM);
    currentY += 40;

    char movesStr[50];
    sprintf(movesStr, "%d", candyMoves);
    if (candyMoves > 10) glColor3f(0.5f, 1.0f, 0.5f);
    else if (candyMoves > 5) glColor3f(1.0f, 1.0f, 0.5f);
    else glColor3f(1.0f, 0.5f, 0.5f);
    drawText(infoStartX, currentY, movesStr, FONT_MEDIUM);
    currentY += 80;

    // Instructions
    glColor3f(0.8f, 0.8f, 1.0f);
    drawText(infoStartX, currentY, "HOW TO PLAY:", FONT_SMALL);
    currentY += 30;

    glColor3f(0.9f, 0.9f, 1.0f);
    drawText(infoStartX, currentY, "1. Click to select candy", FONT_SMALL);
    currentY += 20;
    drawText(infoStartX, currentY, "2. Click adjacent candy", FONT_SMALL);
    currentY += 20;
    drawText(infoStartX, currentY, "3. Match 3+ same color", FONT_SMALL);

    glutSwapBuffers();
}

void candyMouseClick(int x, int y) {
    int glY = WINDOW_HEIGHT - y;

    // Check back button
    if (x >= backButton.x && x <= backButton.x + backButton.width &&
        glY >= backButton.y && glY <= backButton.y + backButton.height) {
        currentScreen = MAIN_MENU;
        glutPostRedisplay();
        return;
    }

    if (isAnimating || candyMoves <= 0) return;

    // Game grid click
    float boardX = 200;
    float boardY = 100;

    int gridX = (x - boardX) / CELL_SIZE;
    int gridY = (glY - boardY) / CELL_SIZE;

    if (gridX >= 0 && gridX < GRID_SIZE && gridY >= 0 && gridY < GRID_SIZE) {
        if (selectedX == -1) {
            // First selection
            selectedX = gridY;
            selectedY = gridX;
        } else {
            // Second selection
            int dx = abs(selectedX - gridY);
            int dy = abs(selectedY - gridX);

            // Check if adjacent
            if ((dx == 1 && dy == 0) || (dx == 0 && dy == 1)) {
                // Store for potential swap back
                swapX1 = selectedX; swapY1 = selectedY;
                swapX2 = gridY; swapY2 = gridX;
                swapCandy1 = candyGrid[selectedX][selectedY];
                swapCandy2 = candyGrid[gridY][gridX];

                // Swap immediately
                swap(candyGrid[selectedX][selectedY], candyGrid[gridY][gridX]);

                // Check for matches
                if (candyHasMatches()) {
                    isAnimating = true;
                    isSwapping = true;
                    animationStep = 0;
                } else {
                    // No matches, swap back
                    swap(candyGrid[selectedX][selectedY], candyGrid[gridY][gridX]);
                }
            }

            // Deselect
            selectedX = -1;
            selectedY = -1;
        }
    } else {
        // Click outside grid - deselect
        selectedX = -1;
        selectedY = -1;
    }

    glutPostRedisplay();
}

void candyMouseMove(int x, int y) {
    int glY = WINDOW_HEIGHT - y;
    backButton.hover = (x >= backButton.x && x <= backButton.x + backButton.width &&
                       glY >= backButton.y && glY <= backButton.y + backButton.height);
    glutPostRedisplay();
}

// ==============================================
// TIC TAC TOE FUNCTIONS
// ==============================================
bool tttCheckWin() {
    // Check rows
    for (int i = 0; i < 3; i++) {
        if (tttGrid[i][0] != 0 && tttGrid[i][0] == tttGrid[i][1] && tttGrid[i][1] == tttGrid[i][2]) {
            return true;
        }
    }

    // Check columns
    for (int i = 0; i < 3; i++) {
        if (tttGrid[0][i] != 0 && tttGrid[0][i] == tttGrid[1][i] && tttGrid[1][i] == tttGrid[2][i]) {
            return true;
        }
    }

    // Check diagonals
    if (tttGrid[0][0] != 0 && tttGrid[0][0] == tttGrid[1][1] && tttGrid[1][1] == tttGrid[2][2]) {
        return true;
    }
    if (tttGrid[0][2] != 0 && tttGrid[0][2] == tttGrid[1][1] && tttGrid[1][1] == tttGrid[2][0]) {
        return true;
    }

    return false;
}

bool tttCheckDraw() {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (tttGrid[i][j] == 0) return false;
        }
    }
    return true;
}

void initTTTGame() {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            tttGrid[i][j] = 0;
        }
    }
    tttTurn = 1;
    tttGameOver = false;
    tttResult = -1;
    tttHighlight = 0;
}

void displayTicTacToe() {
    glClear(GL_COLOR_BUFFER_BIT);
    drawGradientBackground();

    // Draw back button
    drawButton(backButton);

    // Game title
    glColor3f(0.8f, 0.8f, 1.0f);
    string title = "⭕ TIC TAC TOE ❌";
    float titleX = (WINDOW_WIDTH - getTextWidth(title, FONT_LARGE)) / 2;
    drawText(titleX, 650, title, FONT_LARGE);

    // Game board position
    float boardSize = 300;
    float boardX = (WINDOW_WIDTH - boardSize) / 2;
    float boardY = 250;
    float cellSize = boardSize / 3;

    // Draw board background
    glColor3f(0.2f, 0.2f, 0.3f);
    drawRoundedRect(boardX - 10, boardY - 10, boardSize + 20, boardSize + 20, 15);

    // Draw grid lines
    glColor3f(1.0f, 1.0f, 1.0f);
    glLineWidth(4.0f);

    // Vertical lines
    glBegin(GL_LINES);
    glVertex2f(boardX + cellSize, boardY);
    glVertex2f(boardX + cellSize, boardY + boardSize);
    glVertex2f(boardX + 2 * cellSize, boardY);
    glVertex2f(boardX + 2 * cellSize, boardY + boardSize);
    glEnd();

    // Horizontal lines
    glBegin(GL_LINES);
    glVertex2f(boardX, boardY + cellSize);
    glVertex2f(boardX + boardSize, boardY + cellSize);
    glVertex2f(boardX, boardY + 2 * cellSize);
    glVertex2f(boardX + boardSize, boardY + 2 * cellSize);
    glEnd();

    // Draw X's and O's
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            float cx = boardX + j * cellSize + cellSize / 2;
            float cy = boardY + i * cellSize + cellSize / 2;

            if (tttGrid[i][j] == 1) { // X
                glColor3f(0.2f, 1.0f, 0.4f);
                glLineWidth(6.0f);
                glBegin(GL_LINES);
                glVertex2f(cx - 35, cy - 35);
                glVertex2f(cx + 35, cy + 35);
                glVertex2f(cx - 35, cy + 35);
                glVertex2f(cx + 35, cy - 35);
                glEnd();
            } else if (tttGrid[i][j] == 2) { // O
                glColor3f(0.2f, 0.8f, 1.0f);
                glLineWidth(6.0f);
                glBegin(GL_LINE_LOOP);
                for (int k = 0; k < 360; k += 10) {
                    float rad = k * 3.14159f / 180;
                    glVertex2f(cx + 35 * cos(rad), cy + 35 * sin(rad));
                }
                glEnd();
            }
        }
    }

    // Score panel on left
    float panelX = 50;
    float panelWidth = 200;
    float panelHeight = 200;

    glColor3f(0.2f, 0.2f, 0.3f);
    drawRoundedRect(panelX, boardY, panelWidth, panelHeight, 15);

    // Scores
    float textX = panelX + 20;
    float currentY = boardY + 40;

    glColor3f(1.0f, 1.0f, 1.0f);
    drawText(textX, currentY, "SCORE BOARD:", FONT_MEDIUM);
    currentY += 35;

    glColor3f(0.0f, 1.0f, 0.0f);
    string p1 = "Player 1 (X): " + to_string(player1Score);
    drawText(textX, currentY, p1, FONT_MEDIUM);
    currentY += 35;

    glColor3f(0.0f, 0.5f, 1.0f);
    string p2 = "Player 2 (O): " + to_string(player2Score);
    drawText(textX, currentY, p2, FONT_MEDIUM);

    // Score panel on right
    float panelX2 = WINDOW_WIDTH - panelX - panelWidth;
    glColor3f(0.2f, 0.2f, 0.3f);
    drawRoundedRect(panelX2, boardY, panelWidth, panelHeight, 15);

    // Turn indicator
    textX = panelX2 + 20;
    currentY = boardY + 40;

    glColor3f(1.0f, 1.0f, 1.0f);
    drawText(textX, currentY, "CURRENT TURN:", FONT_MEDIUM);
    currentY += 35;

    if (!tttGameOver) {
        if (tttTurn == 1) {
            glColor3f(0.0f, 1.0f, 0.0f);
            drawText(textX, currentY, "Player 1 (X)", FONT_MEDIUM);
        } else {
            glColor3f(0.0f, 0.5f, 1.0f);
            drawText(textX, currentY, "Player 2 (O)", FONT_MEDIUM);
        }
    } else {
        if (tttResult == 0) {
            glColor3f(1.0f, 1.0f, 0.0f);
            drawText(textX, currentY, "DRAW!", FONT_MEDIUM);
        } else if (tttResult == 1) {
            glColor3f(0.0f, 1.0f, 0.0f);
            drawText(textX, currentY, "Player 1 Wins!", FONT_MEDIUM);
        } else {
            glColor3f(0.0f, 0.5f, 1.0f);
            drawText(textX, currentY, "Player 2 Wins!", FONT_MEDIUM);
        }
    }

    // Game over options
    if (tttGameOver) {
        float optionsY = boardY + boardSize + 50;
        float optionWidth = 200;
        float optionHeight = 40;
        float spacing = 15;

        // Center the options
        float optionsCenterX = boardX + boardSize / 2;

        // Draw options background
        glColor3f(0.25f, 0.25f, 0.35f);
        drawRoundedRect(optionsCenterX - optionWidth - spacing/2 - 10,
                       optionsY - 10,
                       optionWidth * 2 + spacing + 20,
                       optionHeight + 20,
                       10);

        // Play Again option
        float playAgainX = optionsCenterX - optionWidth - spacing/2;

        if (tttHighlight == 1) {
            glColor3f(0.3f, 0.7f, 1.0f);
            drawRoundedRect(playAgainX - 5, optionsY - 5, optionWidth, optionHeight, 8);
            glColor3f(1.0f, 1.0f, 1.0f);
        } else {
            glColor3f(0.2f, 0.5f, 0.9f);
            drawRoundedRect(playAgainX, optionsY, optionWidth, optionHeight, 8);
            glColor3f(0.9f, 0.9f, 1.0f);
        }

        string playAgain = "🔄 PLAY AGAIN";
        float playAgainTextX = playAgainX + (optionWidth - getTextWidth(playAgain, FONT_MEDIUM)) / 2;
        drawText(playAgainTextX, optionsY + 12, playAgain, FONT_MEDIUM);

        // Main Menu option
        float mainMenuX = optionsCenterX + spacing/2;

        if (tttHighlight == 2) {
            glColor3f(0.3f, 0.7f, 1.0f);
            drawRoundedRect(mainMenuX - 5, optionsY - 5, optionWidth, optionHeight, 8);
            glColor3f(1.0f, 1.0f, 1.0f);
        } else {
            glColor3f(0.2f, 0.5f, 0.9f);
            drawRoundedRect(mainMenuX, optionsY, optionWidth, optionHeight, 8);
            glColor3f(0.9f, 0.9f, 1.0f);
        }

        string mainMenu = "🏠 MAIN MENU";
        float mainMenuTextX = mainMenuX + (optionWidth - getTextWidth(mainMenu, FONT_MEDIUM)) / 2;
        drawText(mainMenuTextX, optionsY + 12, mainMenu, FONT_MEDIUM);
    }

    glutSwapBuffers();
}

void tttMouseClick(int x, int y) {
    int glY = WINDOW_HEIGHT - y;

    // Check back button
    if (x >= backButton.x && x <= backButton.x + backButton.width &&
        glY >= backButton.y && glY <= backButton.y + backButton.height) {
        currentScreen = MAIN_MENU;
        glutPostRedisplay();
        return;
    }

    if (tttGameOver) {
        // Handle game over options
        float boardSize = 300;
        float boardX = (WINDOW_WIDTH - boardSize) / 2;
        float boardY = 250;
        float optionsY = boardY + boardSize + 50;
        float optionWidth = 200;
        float optionHeight = 40;
        float spacing = 15;
        float optionsCenterX = boardX + boardSize / 2;

        // Calculate option positions
        float playAgainX = optionsCenterX - optionWidth - spacing/2;
        float mainMenuX = optionsCenterX + spacing/2;

        // Check if click is in Play Again button
        if (x >= playAgainX && x <= playAgainX + optionWidth &&
            glY >= optionsY && glY <= optionsY + optionHeight) {
            initTTTGame();
            glutPostRedisplay();
            return;
        }

        // Check if click is in Main Menu button
        if (x >= mainMenuX && x <= mainMenuX + optionWidth &&
            glY >= optionsY && glY <= optionsY + optionHeight) {
            currentScreen = MAIN_MENU;
            glutPostRedisplay();
            return;
        }

        return;
    }

    // Game board click
    float boardSize = 300;
    float boardX = (WINDOW_WIDTH - boardSize) / 2;
    float boardY = 250;
    float cellSize = boardSize / 3;

    int col = (x - boardX) / cellSize;
    int row = (glY - boardY) / cellSize;

    if (row >= 0 && row < 3 && col >= 0 && col < 3 && tttGrid[row][col] == 0) {
        tttGrid[row][col] = tttTurn;

        if (tttCheckWin()) {
            tttGameOver = true;
            tttResult = tttTurn;
            if (tttTurn == 1) player1Score++;
            else player2Score++;
        } else if (tttCheckDraw()) {
            tttGameOver = true;
            tttResult = 0;
        } else {
            tttTurn = (tttTurn == 1) ? 2 : 1;
        }
    }

    glutPostRedisplay();
}

void tttMouseMove(int x, int y) {
    int glY = WINDOW_HEIGHT - y;

    // Back button hover
    backButton.hover = (x >= backButton.x && x <= backButton.x + backButton.width &&
                       glY >= backButton.y && glY <= backButton.y + backButton.height);

    // Game over option highlighting
    if (tttGameOver) {
        float boardSize = 300;
        float boardX = (WINDOW_WIDTH - boardSize) / 2;
        float boardY = 250;
        float optionsY = boardY + boardSize + 50;
        float optionWidth = 200;
        float optionHeight = 40;
        float spacing = 15;
        float optionsCenterX = boardX + boardSize / 2;

        // Calculate option positions
        float playAgainX = optionsCenterX - optionWidth - spacing/2;
        float mainMenuX = optionsCenterX + spacing/2;

        tttHighlight = 0;

        // Check Play Again button
        if (x >= playAgainX && x <= playAgainX + optionWidth &&
            glY >= optionsY && glY <= optionsY + optionHeight) {
            tttHighlight = 1;
        }
        // Check Main Menu button
        else if (x >= mainMenuX && x <= mainMenuX + optionWidth &&
                 glY >= optionsY && glY <= optionsY + optionHeight) {
            tttHighlight = 2;
        }
    } else {
        tttHighlight = 0;
    }

    glutPostRedisplay();
}

// ==============================================
// ANIMATION TIMER
// ==============================================
void animationTimer(int value) {
    if (currentScreen == CANDY_CRUSH && isAnimating) {
        animationStep++;

        if (animationStep >= ANIMATION_STEPS) {
            candyProcessMatches();
            animationStep = 0;
        }
    }

    glutPostRedisplay();
    glutTimerFunc(50, animationTimer, 0);
}

// ==============================================
// MAIN MENU
// ==============================================
void drawMainMenu() {
    glClear(GL_COLOR_BUFFER_BIT);
    drawGradientBackground();
    drawSparkles();

    // Animated title
    if (titleY < 550) titleY += 5;
    else titleY = 550;

    // Main title
    glColor3f(1.0f, 0.9f, 0.9f);
    string title = "✨WELCOME TO THE GAMING WORLD!✨";
    float titleX = (WINDOW_WIDTH - getTextWidth(title, FONT_LARGE)) / 2;
    drawText(titleX, titleY, title, FONT_LARGE);

    // Subtitle
    glColor3f(0.9f, 0.9f, 1.0f);
    string subtitle = "Choose Your Game";
    float subtitleX = (WINDOW_WIDTH - getTextWidth(subtitle, FONT_MEDIUM)) / 2;
    drawText(subtitleX, titleY - 40, subtitle, FONT_MEDIUM);

    // Decorative separator line
    float lineY = titleY - 70;
    glColor3f(0.5f, 0.5f, 0.8f);
    glLineWidth(2.0f);
    glBegin(GL_LINES);
    glVertex2f(WINDOW_WIDTH/2 - 100, lineY);
    glVertex2f(WINDOW_WIDTH/2 + 100, lineY);
    glEnd();

    // Draw buttons
    for (auto& btn : menuButtons) {
        drawButton(btn);
    }

    // Footer
    glColor3f(0.7f, 0.7f, 0.9f);
    string footer = "Made by using OpenGL";
    float footerX = (WINDOW_WIDTH - getTextWidth(footer, FONT_SMALL)) / 2;
    drawText(footerX, 50, footer, FONT_SMALL);

    glutSwapBuffers();
}

// ==============================================
// INPUT HANDLING
// ==============================================
void mouseClick(int btn, int state, int x, int y) {
    if (btn != GLUT_LEFT_BUTTON || state != GLUT_DOWN) return;

    if (currentScreen == MAIN_MENU) {
        int glY = WINDOW_HEIGHT - y;
        for (auto& btn : menuButtons) {
            if (x >= btn.x && x <= btn.x + btn.width &&
                glY >= btn.y && glY <= btn.y + btn.height) {

                switch (btn.id) {
                    case 1: // Candy Crush
                        currentScreen = CANDY_CRUSH;
                        initCandyGrid();
                        break;
                    case 2: // Tic Tac Toe
                        currentScreen = TIC_TAC_TOE;
                        initTTTGame();
                        break;
                    case 3: // Tetris
                        currentScreen = TETRIS;
                        initTetris();
                        glutTimerFunc((int)(tetrisDelay * 1000), tetrisTimer, 0);
                        break;
                    case 4: // Exit
                        exit(0);
                        break;
                }
                glutPostRedisplay();
            }
        }
    } else if (currentScreen == CANDY_CRUSH) {
        candyMouseClick(x, y);
    } else if (currentScreen == TIC_TAC_TOE) {
        tttMouseClick(x, y);
    } else if (currentScreen == TETRIS) {
        // Tetris uses different coordinate system
        int glY = WINDOW_HEIGHT - y;

        // Check back button
        if (x >= backButton.x && x <= backButton.x + backButton.width &&
            glY >= backButton.y && glY <= backButton.y + backButton.height) {
            currentScreen = MAIN_MENU;
            glutPostRedisplay();
        }
    }
}

void mouseMove(int x, int y) {
    int glY = WINDOW_HEIGHT - y;

    if (currentScreen == MAIN_MENU) {
        for (auto& btn : menuButtons) {
            btn.hover = (x >= btn.x && x <= btn.x + btn.width &&
                        glY >= btn.y && glY <= btn.y + btn.height);
        }
        backButton.hover = (x >= backButton.x && x <= backButton.x + backButton.width &&
                          glY >= backButton.y && glY <= backButton.y + backButton.height);
    } else if (currentScreen == CANDY_CRUSH) {
        candyMouseMove(x, y);
    } else if (currentScreen == TIC_TAC_TOE) {
        tttMouseMove(x, y);
    } else if (currentScreen == TETRIS) {
        backButton.hover = (x >= backButton.x && x <= backButton.x + backButton.width &&
                          glY >= backButton.y && glY <= backButton.y + backButton.height);
    }

    glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y) {
    if (currentScreen == TETRIS) {
        switch(key) {
            case 27: // ESC
                currentScreen = MAIN_MENU;
                glutPostRedisplay();
                break;
            case 'p': case 'P':
                if (tetrisGameState == TETRIS_PLAYING)
                    tetrisGameState = TETRIS_PAUSED;
                else if (tetrisGameState == TETRIS_PAUSED)
                    tetrisGameState = TETRIS_PLAYING;
                glutPostRedisplay();
                break;
            case 'r': case 'R':
                if (tetrisGameState == TETRIS_GAMEOVER) {
                    tetrisResetGame();
                }
                break;
            case ' ':
                if (tetrisGameState == TETRIS_PLAYING) {
                    // Hard drop
                    while (true) {
                        for (int i = 0; i < 4; i++) tetrisTemp[i] = tetrisCurrent[i];
                        for (int i = 0; i < 4; i++) tetrisCurrent[i].y += 1;
                        if (!tetrisCheck()) {
                            for (int i = 0; i < 4; i++)
                                tetrisBoard[tetrisTemp[i].y][tetrisTemp[i].x] = tetrisCurrentColor;
                            tetrisScore += 10;
                            tetrisSpawnPiece();
                            break;
                        }
                    }
                    tetrisDx = 0;
                    tetrisRotateFlag = false;
                }
                break;
        }
    } else if (key == 27) { // ESC for other games
        currentScreen = MAIN_MENU;
        glutPostRedisplay();
    }
}

void special(int key, int x, int y) {
    if (currentScreen == TETRIS && tetrisGameState == TETRIS_PLAYING) {
        if (key == GLUT_KEY_LEFT)
            tetrisDx = -1;
        else if (key == GLUT_KEY_RIGHT)
            tetrisDx = 1;
        else if (key == GLUT_KEY_UP)
            tetrisRotateFlag = true;
        else if (key == GLUT_KEY_DOWN)
            tetrisDelay = 0.05;
    }
}

void specialUp(int key, int x, int y) {
    if (currentScreen == TETRIS && key == GLUT_KEY_DOWN)
        tetrisDelay = tetrisInitialDelay * pow(0.9, tetrisLevel - 1);
}

// ==============================================
// DISPLAY FUNCTION
// ==============================================
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Set projection based on current screen
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, WINDOW_WIDTH, 0, WINDOW_HEIGHT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    switch (currentScreen) {
        case MAIN_MENU:
            drawMainMenu();
            break;
        case CANDY_CRUSH:
            displayCandyCrush();
            break;
        case TIC_TAC_TOE:
            displayTicTacToe();
            break;
        case TETRIS:
            displayTetris();
            break;
    }
}

// ==============================================
// MAIN FUNCTION
// ==============================================
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
    glutCreateWindow("🎮 Gaming World!!");

    glClearColor(0.1f, 0.1f, 0.2f, 1.0f);

    initMenu();

    glutDisplayFunc(display);
    glutMouseFunc(mouseClick);
    glutPassiveMotionFunc(mouseMove);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(special);
    glutSpecialUpFunc(specialUp);

    // Start animation timer
    glutTimerFunc(50, animationTimer, 0);

    glutMainLoop();
    return 0;
}
